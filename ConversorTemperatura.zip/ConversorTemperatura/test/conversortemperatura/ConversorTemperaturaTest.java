package conversortemperatura;

import org.junit.Test;
import static org.junit.Assert.*;

public class ConversorTemperaturaTest {

    private final Conversortemperatura conversor = new Conversortemperatura();

    @Test
    public void testCelsiusAFahrenheit() {
        assertEquals(32.0, conversor.celsiusAFahrenheit(0), 0.001);
        assertEquals(212.0, conversor.celsiusAFahrenheit(100), 0.001);
    }

    @Test
    public void testFahrenheitACelsius() {
        assertEquals(0.0, conversor.fahrenheitACelsius(32), 0.001);
        assertEquals(100.0, conversor.fahrenheitACelsius(212), 0.001);
    }
}