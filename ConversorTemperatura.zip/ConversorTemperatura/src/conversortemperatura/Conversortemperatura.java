package conversortemperatura;

public class Conversortemperatura {

    public static void main(String[] args) {
        Conversortemperatura conv = new Conversortemperatura();
        System.out.println("0°C a Fahrenheit: " + conv.celsiusAFahrenheit(0));
        System.out.println("100°C a Fahrenheit: " + conv.celsiusAFahrenheit(100));
        System.out.println("32°F a Celsius: " + conv.fahrenheitACelsius(32));
        System.out.println("212°F a Celsius: " + conv.fahrenheitACelsius(212));
    }

    public double celsiusAFahrenheit(double celsius) {
        return (celsius * 9 / 5) + 32;
    }

    public double fahrenheitACelsius(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }
}