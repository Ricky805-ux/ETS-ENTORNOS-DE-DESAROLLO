public class Edad {
    
    /**
     * Verifica si una persona es mayor de edad (18 años o más)
     * @param edad La edad de la persona
     * @return true si es mayor de edad, false en caso contrario
     * @throws IllegalArgumentException si la edad es negativa
     */
    public boolean isMayorEdad(int edad) {
        if (edad < 0) {
            throw new IllegalArgumentException("La edad no puede ser negativa");
        }
        return edad >= 18;
    }
}