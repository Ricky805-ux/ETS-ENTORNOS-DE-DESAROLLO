package calculadora;

public class Calculadora {

    public static void main(String[] args) {
        Calculadora calc = new Calculadora();
        System.out.println("Suma (2+3): " + calc.sumar(2, 3));
        System.out.println("Resta (5-2): " + calc.restar(5, 2));
        System.out.println("Multiplicación (2*3): " + calc.multiplicar(2, 3));
        System.out.println("División (6/3): " + calc.dividir(6, 3));
    }

    public int sumar(int a, int b) {
        return a + b;
    }

    public int restar(int a, int b) {
        return a - b;
    }

    public int multiplicar(int a, int b) {
        return a * b;
    }

    public int dividir(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("No se puede dividir entre cero.");
        }
        return a / b;
    }
}